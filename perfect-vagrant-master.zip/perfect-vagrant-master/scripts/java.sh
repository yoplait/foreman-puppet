#!/bin/bash
apt-get install -y default-jre
