#!/bin/bash

apt-get install -y mysql-client-5.6
