#!/bin/bash

echo "Installing supervisor"
apt-get install -y supervisor
