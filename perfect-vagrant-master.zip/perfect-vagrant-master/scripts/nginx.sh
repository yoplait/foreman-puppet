#!/bin/bash

echo "Installing nginx"
apt-get install -y nginx
