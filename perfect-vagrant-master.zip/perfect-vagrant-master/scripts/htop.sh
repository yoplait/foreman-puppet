#!/bin/bash
echo "Installing htop"
apt-get install -y htop
