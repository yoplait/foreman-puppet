#!/bin/bash

echo "Updating"
apt-get update
