#!/bin/bash
echo "Installing git"
apt-get install -y git
